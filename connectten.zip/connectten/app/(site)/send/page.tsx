'use client'

import { SendPage } from "@/components/SendPage"

export default function Page() {
  return <SendPage />
}
