'use client'

import { HistoryPage } from "@/components/HistoryPage"

export default function Page() {
  return <HistoryPage />
}
