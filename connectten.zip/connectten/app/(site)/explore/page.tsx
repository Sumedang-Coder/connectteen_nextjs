'use client'

import { ExplorePage } from "@/components/ExplorePage"

export default function Page() {
  return <ExplorePage />
}
